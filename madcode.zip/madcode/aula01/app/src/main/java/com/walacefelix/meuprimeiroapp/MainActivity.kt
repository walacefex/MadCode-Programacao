package com.walacefelix.meuprimeiroapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //configurando um espectador para a acao do botão
        btnOla.setOnClickListener {
            //passando na ação do click do botão para mudar o texto que já está lá
            txvResposta.text = "Olá Lindão"
        }

    }
}
